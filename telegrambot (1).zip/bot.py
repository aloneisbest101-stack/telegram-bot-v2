import os
import telebot

# Token ko Railway ke environment variables se fetch karega
BOT_TOKEN = 7918926285:AAEIe3uPS_7viRkDh40SmMZbLNVJG7UdGMA('BOT_TOKEN')

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Hello! Main aapka Downloader Bot hoon. Mujhe link bhejiye.")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    # Abhi ke liye ye sirf message repeat karega
    # Aap yahan apna downloader logic add kar sakte hain
    bot.reply_to(message, f"Aapne bheja: {message.text}\nDownloading feature jald hi add hoga!")

print("Bot is running...")
bot.infinity_polling()
