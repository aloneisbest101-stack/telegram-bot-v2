import telebot
import requests
import os

BOT_TOKEN = "7918926285:AAEKsZi73F1lhAjUzofCQXMe2SsjyC3VKwk"

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(
        message.chat.id,
        "👋 Send any DIRECT file link (photo, video, pdf).\n\n"
        "⚠️ Login-required links will not work."
    )

@bot.message_handler(func=lambda m: m.text and m.text.startswith("http"))
def download_file(message):
    url = message.text
    try:
        r = requests.get(url, stream=True, timeout=30)
        filename = url.split("/")[-1].split("?")[0] or "file"

        with open(filename, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)

        bot.send_document(message.chat.id, open(filename, "rb"))
        os.remove(filename)

    except Exception as e:
        bot.send_message(
            message.chat.id,
            "❌ Download failed.\nMake sure link is DIRECT."
        )

bot.infinity_polling()